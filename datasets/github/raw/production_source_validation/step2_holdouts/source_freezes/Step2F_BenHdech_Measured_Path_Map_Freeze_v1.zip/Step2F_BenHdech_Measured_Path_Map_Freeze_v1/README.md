# Step 2F Ben Hdech Measured-Path Map Freeze v1

This package freezes the identity of the experimental 40x40 cm2
Figure-62 vector paths for the 6, 16 and 18 MV holdouts.

Frozen mapping:

- 6 MV PDD: path 255
- 6 MV 10-cm profile: path 467
- 16 MV PDD: paths 716 + 717 + 718 + 719
- 16 MV 10-cm profile: paths 942 + 943
- 18 MV PDD: path 1187
- 18 MV 10-cm profile: path 1399

The four 16-MV PDD fragments join at exactly zero distance in rendered
SVG coordinate space.

The two 16-MV profile fragments are preserved exactly as published.
Their endpoints are not snapped or modified.

This package performs no physical axis calibration and creates no
depth, distance, dose, normalized dose, or project-comparison values.

The black source-vector geometry is the experimental measurement.
The red source-vector geometry is the publication's Monte Carlo data
and is not holdout measurement data.

Project predictions remain unseen.
