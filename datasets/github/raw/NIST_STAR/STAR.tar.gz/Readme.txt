ESTAR, PSTAR, and ASTAR Documentation

M. J. Berger

Calculate stopping-power and range tables for electrons,
protons, or helium ions, according to methods described
in ICRU Reports 37 and 49.

____________________________________________________
Table of Contents:

I.	Disclaimer
II.	Why you should use the Web
III.	Version History
IV.	Files for ESTAR
V.	Setup for ESTAR
VI.	Running ESTAR
VII.	Files for PSTAR
VIII.	Setup for PSTAR
IX.	Running PSTAR
X.	Files for ASTAR
XI.	Setup for ASTAR
XII.	Running ASTAR
XIII.	Program Notes
____________________________________________________
I. Disclaimer:

The National Institute of Standards and Technology (NIST)
uses its best efforts to deliver a high quality copy of
the Database and to verify that the data contained therein
have been selected on the basis of sound scientific
judgement. However, NIST makes no warranties to that
effect, and NIST shall not be liable for any damage that
may result from errors or omissions in the Database.
____________________________________________________
II. Why you should use the Web:

	Simple and convenient user interface
	Downloading data in spreadsheet (array) format
	Graphing
	Including the default energies with user defined ones
	Updated regularly

Check out the online version at:

http://physics.nist.gov/Star
____________________________________________________
III. Version History:

Note: For descriptions of the updates, view the source code
of the programs

	Original Release
	January 1993
	Martin J. Berger

	Programming Update (web version 1.0)
	October 1998
	Johnathan S. Coursey

	Programming Update (web version 1.2)
	June 1999
	Johnathan S. Coursey

For more comprehensive version history information see the
online documentation:

http://physics.nist.gov/PhysRefData/Star/Text/verhistory.html
____________________________________________________
IV. Files for ESTAR (in ESTAR zip):

ESTAR.f		Fortran Source
COMPOS.f	Fortran Source
EDCONV.f	Fortran Source for Setup Program
CONVERT.f	Fortran Source for Setup Program
FEDAT		Atomic Data
FCOMP		Material Composition Data
ENG.ELE		Default Energies List
MATS		Set of Materials in the database
material.txt	List of Materials for which there is
		compositional data

for PC only

ESTAR.exe	Stopping Power and Range Table Program
COMPOS.exe	Material Composition Viewing Program
EDCONV.exe	creates UEDAT data file
CONVERT.exe	creates UCOMP data file
____________________________________________________
V. Setup for ESTAR:

1. Make a directory for ESTAR
2. Unzip the ESTAR zip into that directory

Note: PC users can skip step 3

3. Compile (and link) ESTAR.f, COMPOS.f, EDCONV.f, and
CONVERT.f
4. Run the executable version of EDCONV (outputs: UEDAT)
5. Run the executable version of CONVERT (outputs: UCOMP)

To run the program, run ESTAR and follow command line
instructions
____________________________________________________
VI. Running ESTAR:

1. Output Options
	a: Stopping powers, ranges and radiation yields,
           for standard energy grid only
	b: Stopping powers only, for user-selected energy
	   grid

2. Material Selection
	a: Use predefined common material (see material.txt
	   for a list of materials)(use COMPOS to view the
	   compositional data for these materials)
	b: Enter your own material and its compositional data

3. Energy List
	a: Default list, 81 energies between 1 keV and 
	   1000 MeV
	b: User-selected list stored in a file
		- First line contains the number of energies
		  in the list
		- Subsequent lines contain energies in MeV
		  separated by blanks
	c: User-selected list entered as prompted
____________________________________________________
VII. Files for PSTAR (in PSTAR zip):

PSTAR.f		Fortran Source
COMPOS.f	Fortran Source
PCONV.f		Fortran Source for Setup Program
CONVERT.f	Fortran Source for Setup Program
FPROT		Atomic Data
FCOMP		Material Composition Data
ENG.PRO		Default Energies List
MATS		Set of Materials in the database
material.txt	List of Materials for which there is
		compositional data

for PC only

PSTAR.exe	Stopping Power and Range Table Program
COMPOS.exe	Material Composition Viewing Program
PCONV.exe	creates UPROT data file
CONVERT.exe	creates UCOMP data file
____________________________________________________
VIII. Setup for PSTAR:

1. Make a directory for PSTAR
2. Unzip the PSTAR zip into that directory

Note: PC users can skip step 3

3. Compile (and link) PSTAR.f, COMPOS.f, PCONV.f, and
CONVERT.f
4. Run the executable version of PCONV (outputs: UPROT)
5. Run the executable version of CONVERT (outputs: UCOMP)

To run the program, run PSTAR and follow command line
instructions
____________________________________________________
IX. Running PSTAR:

1. Material Selection (see material.txt for a list of 
   materials)(use COMPOS to view the compositional data for
   these materials)

2. Energy List
	a: Default list, 133 energies between 1 keV and 
	   10000 MeV
	b: User-selected list stored in a file
		- First line contains the number of energies
		  in the list
		- Subsequent lines contain energies in MeV
		  separated by blanks
	c: User-selected list entered as prompted
____________________________________________________
X. Files for ASTAR (in ASTAR zip):

ASTAR.f		Fortran Source
COMPOS.f	Fortran Source
ACONV.f		Fortran Source for Setup Program
CONVERT.f	Fortran Source for Setup Program
FALPH		Atomic Data
FCOMP		Material Composition Data
ENG.ALF		Default Energies List
MATS		Set of Materials in the database
material.txt	List of Materials for which there is
		compositional data

for PC only

ASTAR.exe	Stopping Power and Range Table Program
COMPOS.exe	Material Composition Viewing Program
ACONV.exe	creates UALPH data file
CONVERT.exe	creates UCOMP data file
____________________________________________________
XI. Setup for ASTAR:

1. Make a directory for ASTAR
2. Unzip the ASTAR zip into that directory

Note: PC users can skip step 3

3. Compile (and link) ASTAR.f, COMPOS.f, ACONV.f, and
CONVERT.f
4. Run the executable version of ACONV (outputs: UALPH)
5. Run the executable version of CONVERT (outputs: UCOMP)

To run the program, run ASTAR and follow command line
instructions
____________________________________________________
XII. Running ASTAR:

1. Material Selection (see material.txt for a list of 
   materials)(use COMPOS to view the compositional data for
   these materials)

2. Energy List
	a: Default list, 122 energies between 1 keV and 
	   1000 MeV
	b: User-selected list stored in a file
		- First line contains the number of energies
		  in the list
		- Subsequent lines contain energies in MeV
		  separated by blanks
	c: User-selected list entered as prompted
____________________________________________________
XIII. Program Notes:

For calculation information such as uncertainty estimations
see the online documentation:

for ESTAR:

http://physics.nist.gov/PhysRefData/Star/Text/method.html

for PSTAR and/or ASTAR:

http://physics.nist.gov/PhysRefData/Star/Text/programs.html