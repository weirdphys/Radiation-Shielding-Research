      PROGRAM ACONV
C
C     8 September 1992.
C
C     Written by Martin J. Berger,   
C     National Institute of Standards and Technology,
C     Gaithersburg, MD 20899.
C
      DIMENSION STE(122),STN(122),RG(122),DET(122)
      DATA NMAX/122/
      OPEN (UNIT=7,FILE='FALPH')
      OPEN (UNIT=8,FILE='UALPH',FORM='UNFORMATTED',
     1 ACCESS='DIRECT',RECL=1952)
      DO 10 J=1,74
      READ (7,*) (STE(N),N=1,NMAX)
      READ (7,*) (STN(N),N=1,NMAX)
      READ (7,*) (RG(N),N=1,NMAX)
      READ (7,*) (DET(N),N=1,NMAX)
      WRITE (8,REC=J) STE,STN,RG,DET
   10 CONTINUE
      STOP
      END

