      PROGRAM ASTAR
C
C     8 September 1992.
C
C     Version 1.2
C
C     Written by Martin J. Berger,   
C     National Institute of Standards and Technology,
C     Gaithersburg, MD 20899.
C
C     ASTAR produces table of alpha-particle stopping powers, ranges,  
C     detour factors, and average penetration depths, at a chosen set of 
C     emergies. Energies can be entered from keyboard, or from a prepared
C     energy-list file. Such a file must contain, in the first record,
C     the number of energies, and in the next record(s) the energies
C     (in MeV) separated by blanks. 
C
C     ASTAR calls subroutine APOL, which in turn calls 
C     subroutines AREAD, SCOF and BSPOL.
C
C     ASTAR uses input from the direct-access binary file UALPH.
C
C     Minor changes made in October of 1998 for web version 1.0
C     These included: a line too long, and file open routines that
C     were not supported by our compiler (Johnathan S. Coursey)
C
C     Change made June of 1999 for web version 1.2
C     This included: rounding data to 4 significant figures
C     (it is only accurate to 3 anyway) and formatting data into
C     exponential format (Johnathan S. Coursey)
C
      DIMENSION T(1000),STOPEL(1000),STOPNUC(1000),STOPTOT(1000),
     1 RANGE(1000),DETOUR(1000),AVPEN(1000),IDNO(74)
      CHARACTER TAG*72,NAME(74)*72,ENGIN*30,OUTPUT*30
      DATA IDNO/ 1,  2,  4,  6,906,  7,  8, 10, 13, 14, 18, 22, 26, 
     1          29, 32, 36, 42, 47, 50, 54, 64, 74, 78, 79, 82, 92, 
     2          99,101,103,104,106,111,119,120,126,130,134,138,139,
     3         141,155,160,169,179,185,189,191,197,200,201,202,203,
     4         204,209,213,215,216,219,221,222,223,225,226,227,232,
     5         238,245,252,255,263,264,266,276,277/ 
    1 FORMAT(1H ) 
    5 FORMAT(A)
      OPEN (UNIT=7,FILE='MATS')
      DO 10 J=1,74
   10 READ (7,5) NAME(J)
      CLOSE (7)
      PRINT *,' Enter ID number of material: '
      READ *, ID
      DO 20 I=1,74
      IF(IDNO(I).EQ.ID) GO TO 35  
   20 CONTINUE
      PRINT 30, ID
   30 FORMAT(I6,' is not one of the ID numbers in database ASTAR.')
      STOP
   35 TAG=NAME(I)
      PRINT *,' Choice for energy-list input: '
      PRINT *,'    1) Use default file ENG.ALF'
      PRINT *,'    2) Use prepared file'
      PRINT *,'    3) Entry from keyboard'
      PRINT *,' Choose 1, 2, or 3: '
      READ *, INENG
      GO TO (40,50,70), INENG
   40 ENGIN='ENG.ALF'
      OPEN (UNIT=7,FILE=ENGIN)
      READ (7,*) LMAX
      READ (7,*) (T(L),L=1,LMAX)
      CLOSE (7)
      GO TO 75
   50 PRINT *,' Enter name of energy-list file: '
      READ 5, ENGIN
      OPEN (UNIT=7,FILE=ENGIN)
      READ (7,*) LMAX
      READ (7,*) (T(L),L=1,LMAX)
      CLOSE (7)
   55 TMIN=1.0E12
      TMAX=0.0
      DO 60 L=1,LMAX
      IF(T(L).LT.TMIN) TMIN=T(L)
      IF(T(L).GT.TMAX) TMAX=T(L)
   60 CONTINUE
      IF(TMIN-0.001)62,64,64
   62 PRINT 63
   63 FORMAT(' At least one of the specified energies is below 0.001 MeV
     1, out or range.')
      STOP 
   64 IF(TMAX-1000.0)75,75,65
   65 PRINT 66
   66 FORMAT(' At least one of the specified energies is above 0.001 MeV
     1, out or range.')
      STOP
   70 PRINT *,' How many energies?  '
      READ *, LMAX
      PRINT *,' Enter energies (in MeV): '
      READ *, (T(L),L=1,LMAX)
      GO TO 55
   75 PRINT *,' Enter name of output file: '
      READ 5, OUTPUT
      OPEN (UNIT=8,FILE=OUTPUT)
      CALL APOL(ID,LMAX,T,STOPEL,STOPNUC,STOPTOT,RANGE,DETOUR,AVPEN)
      WRITE (8,80)
   80 FORMAT(' ALPHA PARTICLE STOPPING POWER AND RANGE')
      WRITE (8,1)
      WRITE (8,90)
   90 FORMAT('   ID number')
      WRITE (8,100) ID,TAG
  100 FORMAT(I12,3X,A)
      WRITE (8,1)
      WRITE (8,110)
  110 FORMAT('        T = alpha particle (helium ion) kinetic energy, 
     1MeV')
      WRITE (8,120)
  120 FORMAT('  STOP(e) = electronic stopping power, MeV cm2/g')
      WRITE (8,130)
  130 FORMAT('  STOP(n) = nuclear stopping power, MeV cm2/g')
      WRITE (8,140)
  140 FORMAT('  STOP(t) = total stopping power, MeV cm2/g')
      WRITE (8,150)
  150 FORMAT(' RANGE(c) = csda range, g/cm2')
      WRITE (8,160)
  160 FORMAT(' RANGE(p) = projected range, g/cm2')
      WRITE (8,170)
  170 FORMAT('   DETOUR = detour factor')
      WRITE (8,1)
      WRITE (8,180)
  180 FORMAT(10X,'T',4X,'STOP(e)',4X,'STOP(n)',4X,'STOP(t)',
     1 3X,'RANGE(c)',3X,'RANGE(p)',2X,'DETOUR')
      WRITE (8,1)
      DO 200 L=1,LMAX
      WRITE (8,190) T(L),STOPEL(L),STOPNUC(L),STOPTOT(L),RANGE(L),
     1 AVPEN(L),DETOUR(L)
C changed from FORMAT(0PF11.4,1P5E11.3,0PF8.4)
C we wanted the energies to be in exponential form
C Jack Coursey 6/1999
  190 FORMAT(1P6E11.3,0PF8.4)
  200 CONTINUE
      STOP
      END
      SUBROUTINE AREAD (ID,STE,STN,RG,DET)
C     22 Jun 91. Reads binary direct-access file UALPH 
C                for alpha particles.
C
C       Input argument:  
C           ID:  Identification number of material. 
C
C     Output arguments: 
C
C          STE:  Array of NMAX electronic stopping powers, in MeV cm2/g
C          STN:  Array of NMAX nuclear stopping powers, in MeV cm2/g
C           RG:  Array of NMAX csda ranges, in g/cm2
C          DET:  Array of NMAX detour factors
C
      DIMENSION STE(122),STN(122),RG(122),DET(122),IND(74)
      DATA IND/  1,  2,  4,  6,  7,  8, 10, 13, 14, 18, 22, 26, 29, 32,
     1          36, 42, 47, 50, 54, 64, 74, 78, 79, 82, 92, 99,101,103,
     2         104,106,111,119,120,126,130,134,138,139,141,155,160,169,
     3         179,185,189,191,197,200,201,202,203,204,209,213,215,216,
     4         219,221,222,223,225,226,227,232,238,245,252,255,263,264,
     3         266,276,277,906/
      DO 10 J=1,74
      IF(ID.EQ.IND(J)) GO TO 30
   10 CONTINUE
      PRINT 20, ID
   20 FORMAT(I6,' is not a permitted ID number.')
      STOP
   30 JD=J
      OPEN (UNIT=7,FILE='UALPH',FORM='UNFORMATTED',
     1 ACCESS='DIRECT',RECL=1952)
      READ (7,REC=JD) STE,STN,RG,DET
      RETURN
      END
      SUBROUTINE APOL(ID,LMAX,T,STOPEL,STOPNUC,STOPTOT,RANGE,DETOUR,
     1 AVPEN)
C     22 June 1991.
C     
C     Subroutine APOL calculates, by interpolation, alpha-particle 
C     stopping powers, ranges, detour factors and average penetration 
C     depths, at specified energies (between 1 keV and 1000 MeV).
C     
C     Input arguments:
C              ID:  Identification number of material
C            LMAX:  Number of energies
C               T:  Array of LMAX energies, in MeV
C
C     Output arguments:
C          STOPEL:  Array of LMAX electronic stopping powers, in MeV cm2/g
C         STOPNUC:  Array of LMAX nuclear stopping powers, in MeV cm2/g
C         STOPTOT:  Array of LMAX total stopping powers, in MeV cm2/g
C           RANGE:  Array of LMAX csda ranges, in g/cm2
C          DETOUR:  Array of LMAX detour factors
C           AVPEN:  Array of LMAX average penetration depths, in g/cm2
C
      DIMENSION E(122),EL(122),STE(122),STEL(122),STN(122),STNL(122),
     1 RG(122),RGL(122),DET(122),DETL(122),AF(122),BF(122),CF(122),
     2 DF(122),T(1000),TL(1000),STOPEL(1000),STOPNUC(1000),
     3 STOPTOT(1000),RANGE(1000),DETOUR(1000),AVPEN(1000)
      DATA E/
     1 0.0010,0.0015,0.0020,0.0025,0.0030,0.0040,0.0050,0.0060,0.0070,
     2 0.0080,0.0090,0.0100,0.0125,0.0150,0.0175,0.0200,0.0225,0.0250, 
     3 0.0275,0.0300,0.0350,0.0400,0.0450,0.0500,0.0550,0.0600,0.0650,
     4 0.0700,0.0750,0.0800,0.0850,0.0900,0.0950,0.1000,0.1250,0.1500,
     5 0.1750,0.2000,0.2250,0.2500,0.2750,0.3000,0.3500,0.4000,0.4500,
     6 0.5000,0.5500,0.6000,0.6500,0.7000,0.7500,0.8000,0.8500,0.9000,
     7 0.9500,1.0000,1.2500,1.5000,1.7500,2.0000,2.2500,2.5000,2.7500,  
     8 3.0000,3.5000,4.0000,4.5000,5.0000,5.5000,6.0000,6.5000,7.0000,
     9 7.5000,8.0000,8.5000,9.0000,9.5000,10.0000,12.5000,15.0000,
     1 17.5000,20.0000,22.5000,25.0000,27.5000,30.0000,35.0000,40.0000,
     2 45.0000,50.0000,55.0000,60.0000,65.0000,70.0000,75.0000,80.0000,
     2 85.0000,90.0000,95.0000,100.0,125.0,150.0,175.0,200.0,225.0,
     3 250.0,275.0,300.0,350.0,400.0,450.0,500.0,550.0,600.0,650.0,
     5 700.0,750.0,800.0,850.0,900.0,950.0,1000.0/
      DATA NMAX/122/
      CALL AREAD(ID,STE,STN,RG,DET)
      DO 10 L=1,LMAX
      IF(T(L).GT.1000.0) GO TO 70
      IF(T(L).LT.0.001) GO TO 70
   10 TL(L)=LOG(T(L))
      DO 20 N=1,NMAX
      EL(N)=LOG(E(N))
      STEL(N)=LOG(STE(N))
      STNL(N)=LOG(STN(N))
      RGL(N)=LOG(RG(N))
   20 DETL(N)=LOG(DET(N))
      CALL SCOF(EL,STEL,NMAX,AF,BF,CF,DF)
      DO 30 L=1,LMAX
      CALL BSPOL(TL(L),EL,AF,BF,CF,DF,NMAX,RES)
   30 STOPEL(L)=EXP(RES)
      CALL SCOF(EL,STNL,NMAX,AF,BF,CF,DF)
      DO 40 L=1,LMAX
      CALL BSPOL(TL(L),EL,AF,BF,CF,DF,NMAX,RES)
      STOPNUC(L)=EXP(RES)
   40 STOPTOT(L)=STOPEL(L)+STOPNUC(L)
      CALL SCOF(EL,RGL,NMAX,AF,BF,CF,DF)
      DO 50 L=1,LMAX
      CALL BSPOL(TL(L),EL,AF,BF,CF,DF,NMAX,RES)
   50 RANGE(L)=EXP(RES)
      CALL SCOF(EL,DETL,NMAX,AF,BF,CF,DF)
      DO 60 L=1,LMAX
      CALL BSPOL(TL(L),EL,AF,BF,CF,DF,NMAX,RES)
      DETOUR(L)=EXP(RES)
   60 AVPEN(L)=DETOUR(L)*RANGE(L)
      RETURN
   70 PRINT 80,T(L)
   80 FORMAT(' Input energy ',1PE12.5,' out of range.')
      RETURN
      END
      SUBROUTINE SCOF(X,F,NMAX,A,B,C,D) 
C     SUBRROUTINE SCOF(X,F,NMAX,A,B,C,D), 22 FEB 83
C  IF S LIES BETWEEN X(M) AND X(M+1), THEN
C  F(S)=((D(M)*S+C(M))*S+B(M))*S+A(M) 
      DIMENSION X(1000),F(1000),A(1000),B(1000),C(1000),D(1000)
      M1=2
      M2=NMAX-1 
      S=0.0 
      DO 10 M=1,M2
      D(M)=X(M+1)-X(M)
      R=(F(M+1)-F(M))/D(M)
      C(M)=R-S
   10 S=R 
      S=0.0 
      R=0.0 
      C(1)=0.0
      C(NMAX)=0.0 
      DO 20 M=M1,M2 
      C(M)=C(M)+R*C(M-1)
      B(M)=(X(M-1)-X(M+1))*2.0-R*S
      S=D(M)
   20 R=S/B(M)
      MR=M2 
      DO 30 M=M1,M2 
      C(MR)=(D(MR)*C(MR+1)-C(MR))/B(MR) 
   30 MR=MR-1 
      DO 40 M=1,M2
      S=D(M)
      R=C(M+1)-C(M) 
      D(M)=R/S
      C(M)=C(M)*3.0 
      B(M)=(F(M+1)-F(M))/S-(C(M)+R)*S 
   40 A(M)=F(M) 
      RETURN
      END 
      SUBROUTINE BSPOL(S,X,A,B,C,D,N,G)
C     SUBROUTINE BSPOL(S,X,A,B,C,D,N,G), 22 FEB 83
      DIMENSION X(1000),A(1000),B(1000),C(1000),D(1000)
      IF (X(1).GT.X(N)) GO TO 10
      IDIR=0
      MLB=0 
      MUB=N 
      GO TO 20
   10 IDIR=1
      MLB=N 
      MUB=0 
   20 IF (S.GE.X(MUB+IDIR)) GO TO 60
      IF (S.LE.X(MLB+1-IDIR)) GO TO 70
      ML=MLB
      MU=MUB
      GO TO 40
   30 IF (IABS(MU-ML).LE.1) GO TO 80
   40 MAV=(ML+MU)/2 
      IF (S.LT.X(MAV)) GO TO 50 
      ML=MAV
      GO TO 30
   50 MU=MAV
      GO TO 30
   60 MU=MUB+2*IDIR-1 
      GO TO 90
   70 MU=MLB-2*IDIR+1 
      GO TO 90
   80 MU=MU+IDIR-1
   90 Q=S-X(MU) 
      G=((D(MU)*Q+C(MU))*Q+B(MU))*Q+A(MU) 
      RETURN
      END 

