      PROGRAM PCONV
C
C     8 September 1992.
C
C     Written by Martin J. Berger,   
C     National Institute of Standards and Technology,
C     Gaithersburg, MD 20899.
C
      DIMENSION STE(133),STN(133),RG(133),DET(133)
      DATA NMAX/133/
      OPEN (UNIT=7,FILE='FPROT')
      OPEN (UNIT=8,FILE='UPROT',FORM='UNFORMATTED',
     1 ACCESS='DIRECT',RECL=2128)
      DO 10 J=1,74
      READ (7,*) (STE(N),N=1,NMAX)
      READ (7,*) (STN(N),N=1,NMAX)
      READ (7,*) (RG(N),N=1,NMAX)
      READ (7,*) (DET(N),N=1,NMAX)
      WRITE (8,REC=J) STE,STN,RG,DET
   10 CONTINUE
      STOP
      END

